# Comprobaciones reproducibles

Usar pnpm. No añadir paquetes ni cargar credenciales reales solo para correr estas pruebas.

## Pruebas focalizadas (mocks)

```sh
pnpm exec vitest run \
  src/features/music-archive/lib/audio-url-cache.test.ts \
  src/features/music-archive/lib/audio-url-session.test.ts \
  src/features/music-archive/hooks/useMusicAudioPlayback.test.tsx \
  src/features/music-archive/hooks/useMusicAudioSession.test.tsx \
  src/features/music-archive/actions/playback.actions.test.ts \
  src/lib/cloudflare/r2.test.ts \
  'src/app/api/blogs/[idOrSlug]/music/route.test.ts' \
  src/lib/server/chat-attachment-access.test.ts
```

Resultado de referencia: 8 archivos / 84 pruebas aprobadas. Los tests simulan relojes, firmas, audio y auth; no prueban el servicio R2 real.

## Lint de los archivos cambiados

La lista exacta está en `ARCHIVOS_CAMBIADOS.txt`. Desde la raíz de tu checkout puedes pasar al ESLint únicamente los archivos `.ts` y `.tsx` de esa lista (no los JSON de traducciones). Ninguno de los archivos de código cambiado supera 250 líneas.

## TypeScript

```sh
pnpm exec next typegen
pnpm exec tsc --noEmit
```

Resultado de referencia: ambos aprobados. `next-env.d.ts` y `.next/types` son archivos generados; no forman parte del parche.

## Pruebas amplias y build

No ejecutar indiscriminadamente `pnpm test` con `.env` de producción: el setup del repositorio lee `.env.local` y `.env`, y hay suites que llaman Supabase directamente. En esta revisión se probaron las suites offline, sin credenciales, y se comprobaron sus dos fallos preexistentes contra la base exacta. Consulta la exclusión en `SUITES_INTEGRACION_OMITIDAS.txt`.

`pnpm lint` falla igual en base y propuesta: 511 problemas (264 errores / 247 avisos).

El build canónico queda pendiente: la integración Sentry puede transmitir telemetría/artefactos. Requiere un entorno de build seguro/sin transmisión o autorización específica antes de ejecutar esa parte. No se modificó `next.config.ts` ni se deshabilitaron comprobaciones del producto.

## Checklist manual en navegador, pendiente

Usar un entorno local con audio sintético y firmador/auth simulados; no producción.

1. Abrir un álbum sin reproducir: no debe firmar todo el álbum
2. Reproducir A, pausar, continuar, abrir otro álbum y volver a A dentro de vigencia: se reutiliza la misma URL; comprobar contador del firmador de prueba
3. Saltar a otra posición, siguiente/anterior y pulsar rápidamente A/B: ninguna respuesta antigua debe cambiar la pista actual
4. Acortar el TTL solo en el arnés de prueba o adelantar su reloj: renovar antes de caducar, conservando la posición y el estado
5. Dejar la pestaña inactiva y volver después de la expiración simulada: renovar antes de reutilizar una URL caducada
6. Forzar error de audio: un reintento automático; un fallo repetido debe parar y mostrar un mensaje, sin bucle
7. Dejar pendiente una firma y cerrar el reproductor/salir/cambiar cuenta: no debe reaparecer audio ni reutilizar la firma anterior
8. Misma cuenta con nuevo session_id: limpiar; mismo session_id con token renovado: conservar
9. “Mi Música”: reproducción y descarga bajo demanda; JSON sin `audioUrl`, `r2_key` ni firma
10. En un entorno R2 de pruebas que se autorice después: comprobar solicitudes de bytes/Range hacia R2 directamente y confirmar CORS y respuestas reales. Esta parte no se ha ejecutado

La caché de bytes del navegador y el coste final solo pueden medirse con headers y tráfico reales en un entorno autorizado. No se deducen del número de firmas.
