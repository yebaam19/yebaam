# Prompt para Codex local

Trabaja sobre mi checkout existente de Yebaam y prepara la integración local de la primera etapa de reutilización de URLs de audio R2 del paquete adjunto.

Antes de cambiar nada, lee `AGENTS.md`, revisa `git status`, confirma la rama/base actual y examina el parche y `README_ES.md`. La propuesta se generó contra `eed588bb424df549c4c1e27b8dd4f6e9a186f4c1`. No crees ramas ni worktrees, no hagas commit/push/deploy y no sobrescribas cambios previos. Si la base ha avanzado, adapta solo los cambios necesarios después de comparar el diff; ante un conflicto de intención, consulta.

Objetivo: dejar de volver a firmar todas las pistas al renderizar un álbum; reutilizar en memoria URLs todavía válidas dentro de la sesión/pestaña; almacenar expiración real y renovar antes de expirar. Mantén el audio directo navegador → Cloudflare R2. La acción Next existente puede seguir siendo el plano mínimo de firma. No agregues proxy de audio, caché/infraestructura Vercel, Workers, servicios de pago, buckets públicos ni una migración del alojamiento.

Revisa específicamente:
- Cálculo de expiresAt con el mismo signingDate usado por AWS; margen de 60 s y tratamiento del desfase de reloj
- Aislamiento entre usuario/sesión/invitado, rechazo de respuestas tardías, deduplicación, timeout y limpieza al salir/cambiar sesión
- Reproducción, pausa, reanudación, seek, siguiente/anterior, cambio rápido de pista, cierre, renovación conservando posición, recuperación acotada ante errores
- Firma con cliente Supabase caller-bound y RLS, validación del UUID/feature flag, no aceptar claves R2 arbitrarias ni filtrar errores internos
- Contrato `hasAudio` de “Mi Música” y descarga iniciada al pulsar, manteniendo el acceso público existente de música
- Chat, participantes/propiedad, administración y ZIP privado/no-store sin cambios de autorización ni TTL

Primero usa `git apply --check`. Aplica el parche solo localmente si encaja; revisa cada archivo después. Ejecuta las pruebas focalizadas y el lint de los archivos cambiados de `COMPROBACIONES.md`, `pnpm exec next typegen` y `pnpm exec tsc --noEmit`.

No ejecutes scripts de pruebas que autentiquen contra una DB real ni utilices credenciales de producción. Las 15 suites de integración Supabase se omitieron deliberadamente en la validación previa. El lint global y dos pruebas offline ya fallan en la base; reproduce y separa problemas preexistentes, sin resolverlos dentro de esta tarea salvo que bloqueen directamente el cambio y yo lo apruebe.

Antes de ejecutar un build con Sentry, comprueba que no vaya a enviar telemetría, source maps o artefactos fuera. No envíes secretos ni artefactos a terceros ni cambies la configuración de producción para hacer pasar un check. Si necesitas autorización o configuración de test aislada, detente en ese paso y explica exactamente qué falta.

Completa después una verificación manual en navegador local con medios sintéticos y servicios simulados o un entorno de pruebas expresamente autorizado. No uses mi sesión o datos de producción para suplir los mocks. Verifica el checklist de `COMPROBACIONES.md` y deja constancia de lo realmente probado y de lo pendiente.

Entrega un resumen corto del diff final, pruebas aprobadas/fallidas/no ejecutadas y cualquier riesgo restante. No prometas cero peticiones a Vercel, menos bytes o ahorro concreto: esta etapa reduce firmas repetidas y conserva el envío directo de audio desde R2. Espera mi autorización para publicar o desplegar.
