# Yebaam · R2 audio · Etapa 1

Propuesta local para revisión e integración. No está aplicada al repositorio remoto ni desplegada.

Base comprobada: `eed588bb424df549c4c1e27b8dd4f6e9a186f4c1` de `https://github.com/yebaam19/yebaam`, rama `main`, el 30 de septiembre de 2026. Se conservaron intactos los cambios locales anteriores.

## Qué cambia

- La página de álbum deja de firmar todas las pistas en cada render. Solo se solicita una firma al necesitar una pista.
- La misma URL todavía válida se reutiliza en memoria durante la sesión de esa pestaña. La caché está limitada a 128 pistas, sin `localStorage`, `sessionStorage`, disco, service worker ni caché compartida de servidor.
- El firmador devuelve `url`, `expiresAt`, `serverTime` y `viewerId`. La expiración se calcula con el mismo instante, alineado al segundo, que firma AWS para R2.
- Se renueva con 60 segundos de margen. Se comprueba al reproducir, buscar posición, volver al foco y recuperar conexión; mientras se reproduce hay un temporizador de renovación. No se renueva continuamente mientras está en pausa.
- Al renovar se conserva la posición y la intención de reproducción. Solicitudes concurrentes a la misma pista se agrupan; respuestas antiguas no sustituyen una pista nueva ni sobreviven a un cambio de sesión.
- Se limpia caché y reproductor al cerrar sesión, cambiar de usuario/sesión o desmontar el reproductor. Una actualización de token de la misma sesión conserva la caché.
- Un error de audio permite una renovación forzada por ciclo de reproducción, sin bucle infinito. La firma tiene un timeout de 15 segundos. Los fallos dejan un mensaje y permiten reintentar con el botón de reproducción.
- “Mi Música” de los blogs usa el mismo reproductor: su JSON ahora expone `hasAudio`, sin URLs firmadas ni claves R2. Su descarga solicita una URL al pulsar el botón. `?v=2` evita reutilizar respuestas HTTP de la forma antigua.

## Cloudflare y Vercel: alcance exacto

Los bytes de reproducción siguen viajando **del navegador a Cloudflare R2 directamente**. No se crea un proxy de audio, Worker, servicio de pago ni infraestructura de caché en Vercel.

La acción existente `getTrackPlayUrl` de Next.js permanece como plano de control mínimo. Si la aplicación sigue alojada en Vercel, esa acción todavía produce una pequeña petición a Vercel cuando falta una URL o toca renovarla. Esta etapa reduce firmas repetidas; **no significa cero peticiones a Vercel** ni migra el alojamiento.

Reutilizar una URL estable puede ayudar a la caché HTTP del navegador, pero **no garantiza menos bytes descargados ni un ahorro monetario concreto**. Influyen los headers de R2, las solicitudes Range, los buffers y el navegador. No se cambian headers del bucket, CORS, dominios, permisos públicos ni reglas CDN.

## Seguridad conservada

- Se mantienen las lecturas caller-bound de Supabase y RLS; no hay una caché de firmas de servidor entre usuarios.
- La música ya era reproducible anónimamente en la acción original. Se conserva ese comportamiento, con una partición anónima independiente; no se abre un bucket ni se amplían políticas.
- Se validan UUID, feature flag y errores de autenticación/DB. La clave a firmar sale de la fila visible de `music_tracks`, nunca de una clave arbitraria enviada por el navegador. Los errores no devuelven mensajes internos de credenciales.
- El contexto devuelto por el servidor debe coincidir con el usuario esperado. Esta comprobación y la partición cliente **no reemplazan RLS**.
- Chat, autorización de adjuntos, propiedad y participantes permanecen sin cambios. El helper público conserva su resultado string y TTL por defecto de 1 hora; descargas administrativas conservan 15 minutos. La exportación ZIP administrativa y su política privada/no-store no se modifican.
- Como cualquier URL presignada, una copia obtenida antes de salir de sesión conserva su capacidad hasta expirar. La limpieza cliente no revoca una firma ya emitida en R2. No se amplía la duración existente de 1 hora.

## Validación

- **84 pruebas focalizadas aprobadas**, en 8 archivos: firmador/R2, caché, timeout, ciclo del audio, sesiones y cambio de cuenta, respuesta de blog y regresión de autorización de adjuntos de chat. Todas usan mocks/local; ninguna credencial real ni DB de producción.
- **ESLint de todos los archivos cambiados: aprobado, sin avisos.**
- **TypeScript completo (`tsc --noEmit`): aprobado** después de generar los tipos normales de Next (`next typegen`). No se incluye un cambio de configuración para conseguirlo.
- La selección amplia de pruebas offline conserva dos fallos de base: una suite de reacciones necesita configuración Supabase para importar su cliente; una aserción de login espera una URL sin el parámetro `redirect` que el código ya añade. Se reprodujeron ambos en la base limpia exacta. Se omitieron 15 suites que conectan directamente a Supabase, para no tocar datos reales.
- **Lint global no aprobado en la base ni en esta propuesta**: ambos tienen exactamente 511 problemas (264 errores y 247 avisos). No se hizo limpieza ajena a esta tarea.
- **Build de producción no validado.** El intento canónico encontró un límite del entorno con dependencias enlazadas; al volver a intentar, la integración Sentry de la compilación quedó bloqueada porque podría transmitir telemetría/artefactos a un tercero. Se detuvo esa vía. No se autoriza esa transmisión, no se desactiva Sentry en el paquete y no se afirma que el build haya pasado.
- **Navegador real no validado.** Se preparó un arnés de audio WAV local sin producción; el navegador del entorno bloqueó el acceso a la dirección local. Se respetó el bloqueo. Las pruebas DOM de reproducción están aprobadas, pero no sustituyen la comprobación manual con un navegador real.

## Integrar de forma revisable

1. Leer `PROMPT_CODEX_ES.md` y las instrucciones `AGENTS.md` de tu checkout.
2. Confirmar el estado actual y la base de tu repositorio. Si hay cambios concurrentes, no sobrescribirlos.
3. Desde la raíz del repositorio, comprobar primero:
   ```sh
   git apply --check /ruta/al/paquete/yebaam-r2-etapa1.patch
   ```
4. Si la revisión y la comprobación son correctas, aplicar **localmente**:
   ```sh
   git apply /ruta/al/paquete/yebaam-r2-etapa1.patch
   ```
5. Revisar el diff, ejecutar `COMPROBACIONES.md` y completar la prueba manual de navegador antes de considerar un despliegue.

`archivos/` contiene copias revisables de los 23 archivos cambiados. El parche es la opción preferida para integrar: no copiar todo encima de un árbol con trabajo previo. `SHA256SUMS.txt` permite comprobar la integridad de los archivos del paquete.

No incluye `.env`, tokens, claves, node_modules, datos de usuarios, audios reales ni notas internas. No se hicieron commits, push, deploy, migraciones ni cambios en Cloudflare/Supabase.

## Fuentes técnicas

- Cloudflare R2, URLs presignadas y reutilización hasta expirar: https://developers.cloudflare.com/r2/api/s3/presigned-urls/
- Supabase, eventos de sesión del cliente: https://supabase.com/docs/reference/javascript/auth-onauthstatechange
- Código base verificable: https://github.com/yebaam19/yebaam/tree/eed588bb424df549c4c1e27b8dd4f6e9a186f4c1
