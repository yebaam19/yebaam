# Yebaam: revisión de seguridad y reducción de consultas

Preparado el 30 de septiembre de 2026 sobre el repositorio `yebaam19/yebaam`, commit `101b691bf10a069cddd258c79e1dcc68aec65a2b`.

## Estado

Los cambios están preparados y probados localmente. No se hicieron commits, pushes, despliegues, cambios de permisos ni escrituras en producción. Este paquete es para revisión; no certifica todavía el funcionamiento completo en producción.

## Cambios incluidos

- Feed: una misma carga protegida para la primera renderización y la paginación. Verifica positivamente los IDs visibles mediante el cliente del usuario y RLS antes de mostrar o enriquecer las publicaciones. Los errores no exponen contenido sin verificar. Conserva los datos del negocio y las reacciones del usuario.
- Feed: respuestas autenticadas `private, no-store`, paginación entera y acotada, sin caché compartida entre usuarios.
- Propuesta SQL: vincula `get_timeline_posts` con la identidad autenticada, conserva su contrato de 17 columnas, propietario y permisos; excluye muros de páginas/blogs y aplica privacidad antes del límite y del ranking de negocios. Mantiene la excepción existente para tareas confiables con `service_role`. Un guard impide aplicarla si la definición revisada cambió.
- Clubes musicales: listado/detalle pasan de tres consultas a una con conteos relacionados, sin descargar todos los registros de miembros y álbumes. Los conteos respetan RLS y evitan el truncamiento por el límite de filas de la API.
- Medios musicales: hasta siete consultas pasan a cuatro, conservando las asociaciones autorizadas mediante RLS.
- Membresías: rol y estado de ingreso reutilizan una consulta dentro de la misma renderización.
- Géneros: únicamente la taxonomía pública utiliza caché compartida con cliente anónimo sin cookies. Revalidación a los 60 segundos e invalidación inmediata después de crear, editar o borrar desde las acciones existentes. No se comparten datos privados de clubes, miembros ni medios. La revalidación de Next es asíncrona, no un límite estricto de antigüedad.

## Validación

- 47 pruebas de aplicación nuevas: aprobadas, en 9 archivos
- 20 comprobaciones SQL aprobadas en PostgreSQL 17.5 y las mismas 20 en PostgreSQL 18.3, mediante PGlite y datos sintéticos en memoria
- TypeScript completo: aprobado después de generar los tipos de Next
- ESLint de los archivos modificados y pruebas nuevas: aprobado
- `git diff --check` y aplicación del parche con `git apply --check` sobre el commit base: aprobados
- Comprobaciones de solo lectura: la API acepta los conteos relacionados y los joins; se revisaron catálogo, relaciones y políticas sin modificar producción
- Revisión independiente: sin otro defecto concreto nuevo; identificó la dependencia de despliegue SQL primero indicada abajo

La suite completa del repositorio todavía no pasa: el commit base y el código final tienen los mismos 17 archivos fallidos y 6 pruebas fallidas; la mayoría necesita un entorno Supabase configurado y hay una prueba de login ajena a este cambio. Final: 111 aprobadas, 73 omitidas. Base: 64 aprobadas, 73 omitidas. No se proporcionaron credenciales de producción a las pruebas de integración porque algunas insertan y borran registros.

El lint global conserva los mismos 264 errores y 247 advertencias que el commit base. No se modificaron archivos ajenos para ocultarlos.

El build estándar compiló correctamente, pero el entorno terminó su etapa de TypeScript con SIGKILL. Un segundo intento con menor heap también fue terminado. El chequeo TypeScript por separado pasa. No se verificaron el build completo, la generación final de páginas ni los recorridos autenticados en navegador.

## Orden obligatorio de validación y despliegue

1. Aplicar el parche al mismo commit o reconciliar los cambios posteriores. No aplicar directamente sobre trabajo sin revisar.
2. Instalar con `pnpm install --frozen-lockfile` y repetir pruebas, lint, tipos y build en un entorno de staging con recursos y configuración completos.
3. Revisar `docs/security/timeline/README.md`. Validar la propuesta SQL primero en un esquema Supabase completo con las políticas, roles, extensiones y PostgREST reales. Las pruebas sintéticas no sustituyen esta fase.
4. Probar identidad A/B/anónimo, publicaciones propias y de amigos, revocación de amistad, muros de página/blog, negocios seguidos, paginación, primer render, cierre de sesión, regreso y refresco. Verificar también listados musicales y edición de géneros. Medir consultas y planes con datos representativos.
5. Solicitar aprobación específica antes de reemplazar la función en producción. Aplicar SQL primero y comprobar el contrato, la visibilidad y la paginación. Después desplegar el código de aplicación con autorización.

**No desplegar el filtro del feed solo contra la función antigua.** Si se quitan filas después de su LIMIT/OFFSET, una página puede quedar corta o vacía y ocultar publicaciones válidas más antiguas. La propuesta SQL mueve los filtros antes de paginar y resuelve esta incompatibilidad. La protección adicional de la aplicación se conserva para revocaciones, carreras y cambios futuros de políticas.

La función RPC sigue expuesta con su comportamiento actual hasta que se apruebe y despliegue la corrección SQL. No se incluyeron cambios de permisos generales, otras membresías/amistades, limpieza de medios, cron ni almacenamiento. Esos hallazgos necesitan trabajo y validación propios.

## Siguiente paso sin contratar un servicio

Las pruebas sintéticas incluidas ya se pueden ejecutar localmente con los comandos de abajo; no necesitan proyecto Supabase, Docker ni credenciales. Para la validación completa, utilizar un staging existente autorizado o un Supabase local en una máquina con Docker y la CLI oficial, cargando el esquema completo revisado y datos sintéticos. El repositorio no incluye un historial de migraciones completo, por lo que primero se necesita una copia de esquema confiable; no basta con ejecutar esta única función sobre una base vacía. Después configurar las variables del entorno de prueba y ejecutar build y recorridos del navegador. No se creó ni se propone crear automáticamente una rama o servicio de pago: cualquier contratación requiere aprobación previa.

## Reversión

Guardar la definición, propietario y permisos vigentes antes del despliegue autorizado. El contrato conservado permite volver al código anterior de la aplicación manteniendo la función endurecida, sujeto a comprobar compatibilidad en staging. No restaurar automáticamente `original.catalog.txt`: recuperaría la vulnerabilidad de identidad y privacidad. Cualquier reversión de seguridad requiere revisión y aprobación específicas. El guard de la propuesta bloquea tanto una definición que cambió como una segunda aplicación accidental; no retirar ese control para forzar el despliegue.

## Uso del paquete

El archivo `yebaam-security-egress.patch` contiene el código, las pruebas y la documentación SQL. Sobre el commit base:

```sh
git apply --check yebaam-security-egress.patch
git apply yebaam-security-egress.patch
pnpm install --frozen-lockfile
pnpm exec next typegen
pnpm exec tsc --noEmit
```

Pruebas SQL aisladas:

```sh
pnpm --dir supabase/tests/timeline install --frozen-lockfile
node supabase/tests/timeline/run-tests.mjs
```

El paquete aislado agrega dependencias de prueba fijadas; no cambia las dependencias ni el lockfile de la aplicación.
